import "./App.css";
import Tabs from './Tabs';

function App() {

  return (
    <div className="App">
        <Tabs />
    </div>
  );
}
    
export default App;