import './App.css';
import axios  from 'axios';
import React, { useEffect, useState } from 'react';
import Nav from './Nav';
import Footer from './Footer';



const Home = () => {
  const [coupons, setCoupons] = useState(null);
  const [categoryName, setCategoryName] = useState(null);
  const [postCategory, setPostCategory] = useState(0);

//stateb nya masih belom di asys
  useEffect(() => {
    axios.get(`https://user1673281842743.requestly.dev/getCoupon`)
    .then(result => {
      setCoupons(result.data.result);
      console.log(result)
    })
    .catch(err => {
      console.log('error', err);
    })
  },[])

  useEffect(() => {
    axios.get(`https://user1673281842743.requestly.dev/getAllCategory`)
    .then(result => {
      setCategoryName(result.data.result);
    })
    .catch(err => {
      console.log('error', err);
    })
  },[]);

  useEffect(() => {
    console.log('Count is now: ', postCategory);
  }, [postCategory]);

  const handleFilter = () => {
    var element = document.getElementsByClassName(postCategory);
    var elementc = document.getElementsByClassName("cupon");
    for (let i = 0; i < elementc.length; i++) {
      elementc[i].classList.add("hidden");
    }
    for (let i = 0; i < element.length; i++) {
      element[i].classList.remove("hidden");
    }
    // console.log(postCategory)
      var kosong = element.length;
      console.log(kosong)
    if(kosong === 0){
      document.getElementsByClassName("data").innerHTML = '<ol><li>html data</li></ol>';
    }
};

  return ( 
    <div className="container-fluid mx-auto">
        <Nav />
        <div className='box-section'>
      <div className="flex flex-wrap justify-between " >
        <h1 className='w-full mt-5 mb-5 text-white'>Benefit Kupon Untuk Kamu</h1>
        <div className='box-itm-btn flex flex-wrap justify-between w-full'>
      {categoryName?.map((category) => {
                  return <div  className="p-3" key={category.categoryId}>
                      <button className="btn" onClick={() => {
                          setPostCategory(category.categoryName)
                          handleFilter();
                          }}>
                        {category.categoryName} 
                      </button>
                    </div>
          })} 
      </div>
      </div>
      <div className="flex flex-wrap justify-center mt-5 flex-wrap  w-full min-h-[600px]">
        {coupons?.map((coupon) => {
          return <div  className={'m-3 transition-all	 justify-items-center cupon ' + coupon.couponCategoryName}  key={coupon.couponId}>
         
                <div className="card card-compact w-[17rem] bg-base-100 shadow-xl">
                  <figure><img src={coupon.couponBrandLogo} alt={coupon.couponName} /></figure>
                  <div className="card-body">
                    <h2 className="card-title">{coupon.couponName}</h2>
                    <p className='cupon-value'>{coupon.couponBenefitValue}</p>
                    {/* <p>T& C: {coupon.couponTnc}</p> */}
                    <p>Promo Sampai {coupon.couponEndDate}</p>
                    <div className="card-actions ">
                      {/* The button to open modal */}
                    <label htmlFor={coupon.couponId} className="btn btn-block bg-[#26D27F] border-none">Tukarkan</label>
                    {/* Put this part before </body> tag */}
                    <input type="checkbox" id={coupon.couponId} className="modal-toggle" />
                    <div className="modal	">
                      <div className="modal-box w-11/12 max-w-5xl">
                      <div className="card lg:card-side bg-base-100 shadow-xl">
                      <figure className="lg:w-[50%]"><img src={coupon.couponBrandLogo} alt={coupon.couponName} /></figure>
                      <div className="card-body">
                      <p className='benefit-pop'>{coupon.couponBenefitValue}</p>
                        <h2 className="card-title">{coupon.couponName}</h2>
                        <span>Promo sampai  {coupon.couponEndDate}</span>
                        <p className="title-coupoun">
                        <div className='title'>Coupon Successfully Redeemed</div>
                        <p className='jam'>12:30 PM</p>
                        </p>
                        <div className="card-actions justify-end">
                        <label htmlFor={coupon.couponId} className="btn bg-[#26D27F] border-none w-full">DONE!</label>
                        </div>
                      </div>
                    </div>

                      </div>
                    </div>
                    </div>
                    </div>
                  </div>
                </div>
                
          })}
      </div>
      </div>
      
<Footer/>
    </div>
    
  );
}
export default Home;
